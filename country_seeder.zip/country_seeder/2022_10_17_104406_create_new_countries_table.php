<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNewCountriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('new_countries', function (Blueprint $table) {
            $table->id();
            $table->string('code');
            $table->string('name');
            $table->string('calling_codes')->nullable();
            $table->string('capital_rinvex')->nullable();
            $table->text('flag')->nullable();
            $table->string('region')->nullable();
            $table->string('subregion')->nullable();
            $table->string('currencies')->nullable();
            $table->string('currencies_symbol')->nullable();
            $table->string('symbol_name')->nullable();
            $table->string('area')->nullable();
            $table->string('timezones')->nullable();
            $table->string('borders')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('new_countries');
    }
}
