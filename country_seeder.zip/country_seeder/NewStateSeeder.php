<?php

namespace Database\Seeders;
use App\Models\NewCountry;
use App\Models\NewState;
use Illuminate\Database\Seeder;
use PragmaRX\Countries\Package\Countries;
class NewStateSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $countries =   Countries::all();
        foreach ($countries as $key => $value) {
            $getallStates =   $countries->where('cca3',$value->cca3)->first()->hydrateStates()->states->all();
            foreach($getallStates as    $val){
                $sates =  new  NewState();
                $sates->country_id	=  $value->id ?? Null;
                $sates->name	=  $val->name ?? Null;
                $sates->save();
            }
          
        }

    }
}
