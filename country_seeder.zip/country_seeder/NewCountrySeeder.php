<?php

namespace Database\Seeders;

use App\Models\NewCountry;
use Illuminate\Database\Seeder;
use PragmaRX\Countries\Package\Countries;
class NewCountrySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
        $countries =   Countries::all();
        foreach ($countries as $key => $value) {
            $country = new NewCountry();
            $country->name = $value->name->common;
            $country->code = $value->cca3  ?? Null; 
            $country->calling_codes = $value->calling_codes[0] ?? Null;
            $country->flag = $value->flag['flag-icon'] ?? Null;
            // $admin->capital_rinvex = $value->capital_rinvex ?? Null;
            // $admin->area = $value->geo->area  ?? Null;
            // $admin->subregion = $value->geo->subregion ?? Null;
            // $admin->region = $value->geo->region ?? Null;
            // $admin->borders = json_encode($value->geo->borders) ?? Null;
            $country->currencies = $value->currencies[0] ?? Null;
            $country->currencies_symbol = $value->hydrateCurrencies()->currencies->first()->units->major->symbol ?? Null;
            $country->symbol_name = $value->hydrateCurrencies()->currencies->first()->units->major->name ?? Null;
            $country->timezones = $value->hydrate('timezones')->timezones->first()->zone_name ?? Null;
            $country->save();
        }

      
    }
}
